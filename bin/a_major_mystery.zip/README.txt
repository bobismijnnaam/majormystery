GAME
====

The major of ThirtyVille is an illegal poacher! Photograph him doing unlawful activities at three different locations to prove his guilt!

CONTROLS
========

Mouse to look around
Enter to take photos

CONTACT
======
http://www.plusminos.nl
twitter: @broervanlisa
mail: bobrubbens@gmail.com

If there are any problems with copyright, please don't hesitate to notify me.

Made for Ludum Dare 31 Compo.